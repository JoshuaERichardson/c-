﻿using System;

namespace human
{
    class Human
    {
        
        static void Main(string[] args)
        {
            
            
            Console.WriteLine("Hello World!");
            Strength = 10;
            Intelligence = 50;
            Dexterity = 25;
            Health = 100;
            
        }
        
        public string Name(string name)
        {
            Name = name;
        }
        public int Strength
        {
             get { return Strength; }
        }
        public int Intelligence
        {
             get { return Intelligence; }
        }
        public int Dexterity
        {
             get { return Dexterity; }
        }
        private int Health { get; set; }
        public Human(string Name)
        {
            this.Name = Name;
            Strength = 3;
            Intelligence = 3;
            Dexterity = 3;
            Health = 100;
        }
        public Human(string Name, int Strength, int Intelligence, int Dexterity, int Health)
        {
            this.Name = Name;
            this.Strength = Strength;
            this.Intelligence = Intelligence;
            this.Dexterity = Dexterity;
            this.Health = Health;
        }
        public int Attack(object Human)
        {
            Health = Health - Strength*5;
            return Health;
        }
    }
}
