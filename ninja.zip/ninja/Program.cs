﻿using System;
using System.Collections.Generic;

namespace ninja
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
        class Food
        {
            public string Name;
            public int Calories;
            public bool IsSpicy;
            public bool IsSweet;
            public Food(string Name, int Calories, bool IsSpicy, bool IsSweet)
            {
                this.Name = Name;
                this.Calories = Calories;
                this.IsSpicy = IsSpicy;
                this.IsSweet = IsSweet;
            }
        }
        class Buffet
        {
            public List<Food> Menu;
            
            public Buffet()        //constructor
            {
                Menu = new List<Food>()
                {
                    new Food("Pizza", 1000, false, false),
                    new Food("Shrimp", 200, true, true),
                    new Food("Steak", 350, false, false),
                    new Food("Cake", 800, false, true),
                    new Food("Coffee", 15, false, false),
                    new Food("Sweet Tea", 125, false, true),
                    new Food("Just all the food mixed together", 8000, true, true)
                };
            }
            public object Serve()
            {
                Random random = new Random();
                int randInt = random.Next(0,List.Length);
                return Food[randInt];
            }
        }
        class Ninja
        {
            private int calorieIntake = 0;
            public List<Food> FoodHistory;
            public bool IsFull(int calorieIntake)
            {
                if(this.Ninja.calorieIntake < 1200)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            public void Eat(object food)
            {
                if (IsFull(calorieIntake))   // if false run
                {
                    System.Console.WriteLine("This little fattie went to the market");
                }
                else
                {
                    object gonnaEatThat = Serve();
                    calorieIntake += gonnaEatThat.Calories;
                    FoodHistory.add(gonnaEatThat);
                    System.Console.WriteLine($"O good yum yum food: {gonnaEatThat.Name}.  Spicy: {gonnaEatThat.IsSpicy}.  Sweet: {gonnaEatThat.IsSweet}");
                }
            }
        }
    }
}
